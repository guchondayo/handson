const array = [1, 2, 3, 4, 5, 6];

array.unshift('new item');
array.push('new item');
array.shift();
array.pop();

console.log(array);