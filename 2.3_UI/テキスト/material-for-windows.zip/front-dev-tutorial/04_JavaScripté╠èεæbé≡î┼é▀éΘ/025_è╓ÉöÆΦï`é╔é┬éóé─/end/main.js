function hello(name, age) {
    // let name = 'Code Mafia';
    console.log('hello ' + name + age);
    return name + age;
}
hello('Code Mafia', 10);
const returnVal = hello('Code Mafia 2', 20);
console.log(returnVal);
